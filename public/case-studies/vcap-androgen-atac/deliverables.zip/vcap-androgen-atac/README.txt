OmicsDesk — ATAC-seq case study deliverable
VCaP prostate cancer, vehicle vs DHT (androgen stimulation), GSE214753

Contents:
  report.pdf             22-page branded analysis report (methods, QC, results, interpretation)
  results_workbook.xlsx  All result tables: QC, peak annotation, differential accessibility
                         (with nearest-gene symbols), chromVAR TF activity, TOBIAS footprints,
                         pathway enrichment
  figures/               15 publication-quality PNG figures from the report

Pipeline: fastp + Bowtie2 + MACS3 + ChIPseeker + deepTools + DiffBind + chromVAR + TOBIAS.
Reproducible Snakemake workflow with pinned conda environments.
Questions: hello@omicsdesk.com
