OmicsDesk — sample deliverables (scRNA-seq case study: mouse heart TAC time course)

Contents:
  report.pdf              — 30-page branded PDF report
  results_workbook.xlsx   — Excel workbook (QC, cell-type proportions, significant markers + DEGs)
  figures/                — 23 PNG figures (web-resized for this sample download)

This is a web-friendly sample. Live client deliveries include:
  - The full 300 dpi PNGs at original publication resolution
  - The full uncompressed PDF (~19 MB) with high-res embedded figures
  - The complete Excel workbook including "All Markers" + "All DEGs" sheets (~600k rows)
  - The AnnData (.h5ad) object for downstream re-analysis
  - The Snakemake pipeline code + pinned conda environment specs

Get a quote: hello@omicsdesk.com
More case studies: https://omicsdesk.com/case-studies/
