OmicsDesk — sample deliverables (RNA-seq case study: BRAF melanoma + romidepsin/IFN)

Contents:
  report.pdf              — 14-page branded PDF report (exec summary, methods, figures, conclusions)
  results_workbook.xlsx   — Excel workbook with DESeq2 results per contrast, pathway enrichment,
                            transcription-factor activity scores
  figures/                — 10 publication-quality PNG figures, 300 dpi
                            (PCA, volcano plots per contrast, pathway enrichment, TF activity,
                             heatmap, upset plot)

This is the public sample. Live client deliveries also include:
  - The full Snakemake pipeline code + pinned conda environment specs
  - Per-step QC reports (HTML)
  - Versioned config and run logs
  - Optional raw count matrices and intermediate result files

Get a quote for your own data: hello@omicsdesk.com
More case studies: https://omicsdesk.com/case-studies/
